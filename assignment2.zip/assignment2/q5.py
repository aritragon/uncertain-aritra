#Implemention of the shooting method for the boundary value problem.
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

n=11
g=9.8
t = [i for i in np.linspace(0,10,n)]
def fn(t, w): 
	g = 10
	x = w[1]			#differential eqns declaration
	v = w[0]
	dvdt = -g
	dxdt = v
	return [dvdt, dxdt]

def fn1(ti, tf, w0):
	soln = solve_ivp(fn, [ti, tf], w0, t_eval = [tf])	#usage of Solve_ivp to evatuate at a particular time
	return [soln.y]

def fn2(ti, tf, w0):
	sol = solve_ivp(fn, [ti, tf], w0, t_eval=t)	#usage of Solve_ivp to evatuate at several time steps
	return [sol.y]	


w0 = [-50., 0.]		#Initial two guesses on v and x
w1 = [100., 0.]
wg = [0., 0.]

solvg=[]
ti = 0.0
tf = 10.0

sol = s(ti, tf, w0)
cnt = 0

solv1 = s(ti, tf, w0)
solv2 = s(ti, tf, w1)

if (solv1[0][1]*solv2[0][1]<0):
	while(abs(sol[0][1]) > 0.0001):
		w_mid = (w1[0] + w0[0])/2.0 
		wg[0] = w_mid 
		solg = fn1(ti, tf, wg)
		solvg.append(fn2(ti, tf, wg)[0][1])
	
		if (solg[0][1]*solv1[0][1]>=0):
			w0[0] = wg[0]
			solv1 = fn1(ti, tf, w0)
			sol = solv1
		else:
			w1[0] = wg[0]  			 #bisection method
			solv2 = fn1(ti, tf, w1)
			sol = solv2
		
		cnt = cnt + 1
else:
		print("Wrong initial guesses")
#print(cnt)

y = np.asarray(solvg)

plt.plot(t, y[0,:], label = "1th soln")
plt.plot(t, y[1,:], label = "2th soln")
plt.plot(t, y[2,:], label = "3th soln")
plt.plot(t, y[3,:], label = "4th soln")
plt.plot(t, y[cnt-1,:],color='k', label = "actual")
plt.legend(loc=0)
plt.xlabel('t')
plt.ylabel('y(t)')
#plt.savefig('fig_q5.png')
plt.show()









		
