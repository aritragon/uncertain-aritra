#Use the Runge-Kutta Method to solve the differential equation.
import numpy as np
import math
import matplotlib.pyplot as plt
h=0.1
x=0.0
y=0 #initial conditions
v=0
T=[]
x1=[]
x2=[]

def fn(y,v,x):
	return(2*v-y+x*math.exp(x)-x)  #differential eqns declaration

while(x<=1):
	x1.append(y)
	x2.append(v)
	T.append(x)
	#print("t=",x,"\t","y=",y,"\t","v=",v,"\n")
	k1=h*(v)
	p1=h*(fn(y,v,x))
	k2=h*(v+p1/2)			#splitting eqn into two 1st order eqn
	p2=h*(fn(y+k1/2,v+p1/2,x+h/2))
	k3=h*(v+p2/2)
	p3=h*(fn(y+k2/2,v+p2/2,x+h/2))
	k4=h*(v+p3)
	p4=h*(fn(y+k3,v+p3,x+h))
	y=y+(1/6)*(k1+2*k2+2*k3+k4)
	v=v+(1/6)*(p1+2*p2+2*p3+p4)
	x=x+h

a1 = np.asarray(x1)
a2 = np.asarray(x2)
t= np.asarray(T)

plt.plot(t,a1,color="r",label="y(t)")
plt.plot(t,a2,color="g",label="y'(t)")
plt.xlabel('x')    			#plotting
plt.ylabel("y(x) and y'(x)")
plt.legend()
plt.show()
