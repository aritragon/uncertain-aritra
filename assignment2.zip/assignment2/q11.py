#Use of RK4 to solve the initial value problem
import numpy as np
import math
import matplotlib.pyplot as plt
h=0.01
t=0.0
u1=3 #initial conditions
u2=-1
u3=1
T=[]
x1=[]
x2=[]
x3=[]
def fn1(t,u1,u2,u3):
	return(u1+2*u2-2*u3+math.exp(-t))
def fn2(t,u1,u2,u3):
	return(u2+u3-2*math.exp(-t))
def fn3(t,u1,u2,u3):			##differential eqns declaration
	return(u1+2*u2+math.exp(-t))

while(t<=1):
	x1.append(u1)
	x2.append(u2)
	x3.append(u3)
	T.append(t)
	#print("t=",x,"\t","y=",y,"\t","v=",v,"\n")
	k1=h*(fn1(t,u1,u2,u3))
	p1=h*(fn2(t,u1,u2,u3))
	s1=h*(fn3(t,u1,u2,u3))

	k2=h*(fn1(t+h/2,u1+k1/2,u2+p1/2,u3+s1/2))
	p2=h*(fn2(t+h/2,u1+k1/2,u2+p1/2,u3+s1/2))
	s2=h*(fn3(t+h/2,u1+k1/2,u2+p1/2,u3+s1/2))

	k3=h*(fn1(t+h/2,u1+k2/2,u2+p2/2,u3+s2/2))  #RK4 method
	p3=h*(fn2(t+h/2,u1+k2/2,u2+p2/2,u3+s2/2))
	s3=h*(fn3(t+h/2,u1+k2/2,u2+p2/2,u3+s2/2))

	k4=h*(fn1(t+h,u1+k3,u2+p3,u3+s3))
	p4=h*(fn2(t+h,u1+k3,u2+p3,u3+s3))
	s4=h*(fn3(t+h,u1+k3,u2+p3,u3+s3))

	u1=u1+(1/6)*(k1+2*k2+2*k3+k4)
	u2=u2+(1/6)*(p1+2*p2+2*p3+p4)
	u3=u3+(1/6)*(s1+2*s2+2*s3+s4)
	t=t+h

a1 = np.asarray(x1)
a2 = np.asarray(x2)
a3 = np.asarray(x3)
time= np.asarray(T)

plt.plot(time,a1,color="r",label="u1(t)")
plt.plot(time,a2,color="g",label="u2(t)")
plt.plot(time,a3,color="b",label="u3(t)")
plt.xlabel('t')    #plotting
plt.ylabel('u(t)')
plt.legend()
plt.show()
