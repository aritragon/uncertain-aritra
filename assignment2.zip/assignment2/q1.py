#Solving differential equation using backward integration method
import numpy as np
import math
import matplotlib.pyplot as plt
h=0.001
cnt=0.0
w1=math.exp(1.0) #initial conditions
w2=1.0/3.0
T=[]
x1=[]
x2=[]
def fn1(h,w1):
	return (w1/(1+9*h))  #differential eqns declaration

def fn2(h,cnt,w2):
	x=math.sqrt(w2/(20*h)+math.pow((1/(40*h)-cnt-h),2)+(cnt+h)/10-math.pow((h+cnt),2))-(1/(40*h)-cnt-h)
	return x

while (cnt<=1.0):
	x1.append(w1)
	x2.append(w2)	
	T.append(cnt)
	w1=fn1(h,w1)  # solving using backward integration
	w2=fn2(h,cnt,w2)
	cnt=cnt+h

a1 = np.asarray(x1)
a2 = np.asarray(x2)
t= np.asarray(T)

plt.plot(t,a1,color="r")
plt.plot(t,a2,color="g")
plt.xlabel('x')    #plotting
plt.ylabel('y(x)')
plt.show()
