#Use of Euler’s method to solve the initial value problem
import numpy as np
import math
import matplotlib.pyplot as plt
h=0.001
t=1.0
y=1 #initial conditions
v=0
T=[]
x1=[]
true=[]
def fn1(t,y,v):
	return(2*v/t-2*y/(t*t)+t*math.log(t))			#differential eqns declaration

def fn2(t,y):		
	return(7*t/4+(t*t*t/2)*math.log(t)-(3/4)*t*t*t) #analytic solution

while(t<=2):
	x1.append(y)
	true.append(fn2(t,y))
	T.append(t)
	y=y+h*v 		#euler method
	v=v+h*fn1(t,y,v)
	t=t+h

a1 = np.asarray(x1)
a2 = np.asarray(true)
time= np.asarray(T)

plt.plot(time,a1,color="y",linestyle="None",marker="o",markersize="3",label="numerical")
plt.plot(time,a2,color="k",linestyle="None",marker="*",markersize="1",label="true solution")
plt.xlabel('t')    #plotting
plt.ylabel('y(t)') 
plt.legend()
plt.show()
