#Implemention of the relaxation method for boundary value problem
import numpy as np
from numpy.linalg import solve
from scipy.integrate import solve_ivp
from numpy.linalg import inv
import matplotlib.pyplot as plt
ti=0
tf=10
h=0.1
n=int((tf-ti)/h)
g=10
a1=0
a2=0

A=np.zeros((n-1,n-1))
b=np.ones(n-1)
c=np.zeros(n-1)
b=np.dot(-g*h*h,b)  #Building A,b,c where A is (n-1) dimensional matrix b,c are n dim vectors..we want to form a matrix eqn of the form Ax+c=b and the solve for x.
x=np.zeros(n+1)  
t=np.zeros(n+1)
y=np.zeros(n+1)
x[0]=a1
x[n]=a2
y[0]=a1
y[n]=a2
t[0]=ti
t[n]=tf
X=np.zeros(n+1)
c[0]=a1
c[n-2]=a2
for i in range(0,n-1):
	A[i][i]=-2
	if (i==0):
		A[i][i+1]=1
	elif(i==n-2):			#Forming matrix A which is tridiagonal matrix
		A[i][i-1]=1
	else:
		A[i][i-1]=1
		A[i][i+1]=1

#print(A)
x1=np.dot(inv(A),b-c) #solving for x
#x1= solve(A,b-c)
for i in range(0,n-1):
	t[i+1]=t[i]+h   # For comparison with actual analytic solution
	y[i+1] = 0.1*(10*a1 +a2*t[i+1] - a1*t[i+1] + 50*g*t[i+1] -5*g*t[i+1]*t[i+1])
for i in range(0,n-1):
	x[i+1]=x1[i]  #n+1 dim vector with initial condition placed 


plt.plot(t,x,color="r",marker="o",linestyle="None",markersize="3",label="numerical")
plt.plot(t,y,color="k",marker="*",markersize="1",label="analytic")
plt.xlabel('t')    #plotting
plt.ylabel('y(t)') 
plt.legend()
plt.show()

