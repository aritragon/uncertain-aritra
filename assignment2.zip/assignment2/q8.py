#Use of scipy.integrate.solve_bvp to solve boundary value problems. 
import numpy as np
import math
from scipy.integrate import solve_bvp
import matplotlib.pyplot as plt

n=50

def f1(t,w):
	dydt=w[1]	
	dvdt=-np.exp(-2*w[0])
	return np.vstack ((dydt,dvdt))

def f2(t,w):
	dydt=w[1]	
	dvdt=w[1]*np.cos(t)-w[0]*np.log(w[0])
	return np.vstack ((dydt,dvdt))

def f3(t,w):						#differential eqns declaration
	dydt=w[1]	
	dvdt=-(2*w[1]*w[1]*w[1]+(w[0]*w[0])*w[1])*(1/np.cos(t))
	return np.vstack ((dydt,dvdt))

def f4(t,w):
	dydt=w[1]	
	dvdt=(1.0/2.0)-0.5*w[1]*w[1]-w[0]*np.sin(t)*0.5
	return np.vstack ((dydt,dvdt))
##############################################################
def tr1(t):
	y=math.log(t)
	return (y)
def tr2(t):
	y=math.exp(math.sin(t))			#analytic solution
	return (y)
def tr3(t):
	y=math.sqrt(math.sin(t))
	return (y)
def tr4(t):
	y=2+math.sin(t)
	return (y)
################################################################

t1=np.linspace(1,2,n)
t2=np.linspace(0,math.pi/2,n)
t3=np.linspace(math.pi/4,math.pi/3,n)
t4=np.linspace(0,math.pi,n)
X1=np.zeros((n,1))
X2=np.zeros((n,1))
X3=np.zeros((n,1))
X4=np.zeros((n,1))

def bc1(ya, yb):
    return np.array([ya[0]-0, yb[0]-math.log(2)])
def bc2(ya, yb):
    return np.array([ya[0]-1, yb[0]-math.exp(1)])			#boundary conditions
def bc3(ya, yb):
    return np.array([ya[0]-math.pow(2,-0.25), yb[0]-math.pow(12,0.25)/2])
def bc4(ya, yb):
    return np.array([ya[0]-2.0, yb[0]-2.0])


y_a1 = np.zeros((2, t1.size))
y_a2 = np.ones((2, t2.size))
y_a3 = np.zeros((2, t3.size)) 		#initial guesses of the solution 
y_a4 = np.ones((2, t4.size))

a1 = solve_bvp(f1,bc1 , t1, y_a1)
a2 = solve_bvp(f2,bc2 , t2, y_a2)
a3 = solve_bvp(f3,bc3 , t3, y_a3)		#using solve_bvp
a4 = solve_bvp(f4,bc4 , t4, y_a4)

###############################################################

for i in range (0,n):
	X1[i][0]=tr1(t1[i])
	X2[i][0]=tr2(t2[i])
	X3[i][0]=tr3(t3[i])
	X4[i][0]=tr4(t4[i])
###############################################################	

figure, axes = plt.subplots(nrows=2, ncols=2)

axes[0, 0].plot(t1,X1,color="y",marker="o",markersize="3",label="analytic")
axes[0, 0].plot(t1,a1.sol(t1)[0],color="r",label="numerical")
axes[0, 0].set_xlabel('t')
axes[0, 0].set_ylabel('y(t)')
axes[0, 0].legend()

axes[0, 1].plot(t2,X2,color="y",marker="o",markersize="3",label="analytic")
axes[0, 1].plot(t2,a2.sol(t2)[0],color="b",label="numerical")
axes[0, 1].set_xlabel('t')
axes[0, 1].set_ylabel('y(t)')
axes[0, 1].legend()				#plotting

axes[1, 0].plot(t3,X3,color="y",marker="o",markersize="3",label="analytic")
axes[1, 0].plot(t3,a3.sol(t3)[0],color="k",label="numerical")
axes[1, 0].set_xlabel('t')
axes[1, 0].set_ylabel('y(t)')
axes[1, 0].legend()

axes[1, 1].plot(t4,X4,color="y",marker="o",markersize="3",label="analytic")
axes[1, 1].plot(t4,a4.sol(t4)[0],color="g",label="numerical")
axes[1, 1].set_xlabel('t')
axes[1, 1].set_ylabel('y(t)')
axes[1, 1].legend()

figure.tight_layout()
plt.show()






