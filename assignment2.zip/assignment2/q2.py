#Solving differential equation using euler method and calculating absolute and relative error.
import numpy as np
import math
import matplotlib.pyplot as plt
h=0.1
cnt=1.0
w1=1.0  #initial conditions
tr=0
error=0
relerr=0
T=[]
x1=[]
x2=[]
err=[]
rel_err=[]

def fn1(h,w1,cnt):
	return (w1/cnt-math.pow((w1/cnt),2))	#differential eqns declaration

def true(cnt):
	return (cnt/(1+math.log(cnt)))  #analytic solution

tr=true(cnt)

while (cnt<=2.0):
	x1.append(w1)
	x2.append(tr)
	tr=true(cnt)	
	T.append(cnt)
	err.append(error)
	rel_err.append(relerr)
	w1=w1+h*fn1(h,w1,cnt)
	error=abs(w1-tr)   # calculation of rel and abs error
	relerr=error/tr
	print("abs_err=",error,"\t","abs_err=",relerr,"\n")   #printing values
	cnt=cnt+h

a1 = np.asarray(x1)
a2=np.asarray(x2)
t= np.asarray(T)
E1=np.asarray(err)
E2=np.asarray(rel_err)
#plt.plot(t,a1,color="r")
#plt.plot(t,a2,color="k")
#plt.plot(t,E1,color="m")
#plt.plot(t,E2,color="g")
#plt.xlabel('x')
#plt.ylabel('y(x)')
#plt.show()
