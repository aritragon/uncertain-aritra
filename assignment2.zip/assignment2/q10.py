# solving differential equation with infinite time domain
import numpy as np
import math
import matplotlib.pyplot as plt
def fn(y,u):
	return ((np.power((1-u), -2)*(1/(math.pow(y, 2) + math.pow(u/(1-u), 2))))) #defination of diff eqn

T=[]
x1=[]


u = 0.
y = 1.
h = 0.001

tl = 3.5*math.pow(10, 6)
ul = tl/(tl + 1) # Change of variable

while(u<=1):
	x1.append(y)
	T.append(u)
	p1=h*(fn(y,u))	
	p2=h*(fn(y+p1/2,u+h/2))
	p3=h*(fn(y+p2/2,u+h/2))
	p4=h*(fn(y+p3,u+h))   #RK4 method
	if(abs(u-ul)<0.001):
		sol=y
	y=y+(1./6.)*(p1+2*p2+2*p3+p4)
	
	u=u+h


print("t=",tl,"\t","x=",sol)
a1 = np.asarray(x1)
t= np.asarray(T)

plt.plot(t,a1,color="r")
plt.xlabel('u')    #plotting
plt.ylabel("x(u)")
plt.show()
