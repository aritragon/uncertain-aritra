#Use of scipy.integrate.solve_ivp to solve the initial value problems.
import numpy as np
import math
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

n=101
T1=0
T2=2
T3=1
T4=0
h=0.01	
X1=np.zeros((n,1))
X2=np.zeros((n,1))
X3=np.zeros((n,1))
X4=np.zeros((n,1))
t1=np.zeros((n,1))
t2=np.zeros((n,1))
t3=np.zeros((n,1))
t4=np.zeros((n,1))
############################################################
def f1(t,w):
	dydt=t*math.exp(3*t)-2*w
	return [dydt]
def f2(t,w):
	dydt=1-math.pow(t-w,2)
	return [dydt]				#differential eqns declaration
def f3(t,w):
	dydt=1+w/t
	return [dydt]
def f4(t,w):
	dydt=math.cos(2*t)+math.sin(3*t)
	return [dydt]

###########################################################
def tr1(t):
	y=(1/25)*math.exp(-2*t)*(1-math.exp(5*t)+5*t*math.exp(5*t))
	return (y)
def tr2(t):
	y=t
	return (y)				#analytic solution
def tr3(t):
	y=2*t+t*math.log(t)
	return (y)
def tr4(t):
	y=(4./3.)-(1./3.)*math.cos(3*t)+(1./2.)*math.sin(2*t)
	return (y)

sol1 = solve_ivp(f1, [0, 1], [0],t_eval=[i for i in np.linspace(0,1,n)])	
sol2 = solve_ivp(f2, [2, 3], [2],t_eval=[i for i in np.linspace(2,3,n)])	#using solve_ivp
sol3 = solve_ivp(f3, [1, 2], [2],t_eval=[i for i in np.linspace(1,2,n)])	
sol4 = solve_ivp(f4, [0, 1], [1],t_eval=[i for i in np.linspace(0,1,n)])

for i in range (0,n):
	t1[i][0]=T1
	X1[i][0]=tr1(T1)
	t2[i][0]=T2
	X2[i][0]=tr2(T2)
	t3[i][0]=T3
	X3[i][0]=tr3(T3)  #storing actual solution
	t4[i][0]=T4
	X4[i][0]=tr4(T4)
	T1=T1+h
	T2=T2+h
	T3=T3+h
	T4=T4+h

y1=np.transpose(np.asarray(sol1.y))

y2=np.transpose(np.asarray(sol2.y))

y3=np.transpose(np.asarray(sol3.y))

y4=np.transpose(np.asarray(sol4.y))

#######################################################
figure, axes = plt.subplots(nrows=2, ncols=2)


axes[0, 0].plot(t1,y1,color="y",marker="o",markersize="3",label="numerical")
axes[0, 0].plot(t1,X1,color="k",label="analytic")
axes[0, 0].set_xlabel('t')
axes[0, 0].set_ylabel('y(t)')
axes[0, 0].legend()

axes[0, 1].plot(t2,y2,color="y",marker="o",markersize="3",label="numerical")
axes[0, 1].plot(t2,X2,color="k",label="analytic")
axes[0, 1].set_xlabel('t')
axes[0, 1].set_ylabel('y(t)')					#plotting
axes[0, 1].legend()

axes[1, 0].plot(t3,y3,color="y",marker="o",markersize="3",label="numerical")
axes[1, 0].plot(t3,X3,color="k",label="analytic")
axes[1, 0].set_xlabel('t')
axes[1, 0].set_ylabel('y(t)')
axes[1, 0].legend()

axes[1, 1].plot(t4,y4,color="y",marker="o",markersize="3",label="numerical")
axes[1, 1].plot(t4,X4,color="k",label="analytic")
axes[1, 1].set_xlabel('t')
axes[1, 1].set_ylabel('y(t)')
axes[1, 1].legend()

figure.tight_layout()
plt.show()
