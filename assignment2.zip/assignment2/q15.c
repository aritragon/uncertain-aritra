/*Euler’s method to solve the initial value problem and finding error and error bound*/
#include <stdio.h>
#include<stdlib.h>
#include<math.h>

double fn(float t, float y)
{
    return(y-t*t+1);
}

double fn2(float t)			/*differential eqns declaration*/
{
    return(pow((t+1),2)-0.5*exp(t));
}

int main()
{

	/*FILE *mptr;
    	mptr=fopen("eval.dat","w");*/


	float ti,tf,dt;
	int i,n;
	ti=0;
	tf=2;
	dt=0.2;
	n=(tf-ti)/dt+1;
	double y[n],yr[n],t[n],err[n],erb[n];
	y[0]=0.5;
	t[0]=0;
	yr[0]=0.5;
	err[0]=0.0;
	erb[0]=0.0;
	printf("t=");
	printf("%lf\t",t[0]);
	printf("error=");
	printf("%lf\t",err[0]);
	printf("error bound=");
	printf("%lf\n",erb[0]);
	/*fprintf(mptr,"%e\t%e\t%e\n",t[0],y[0],yr[0]);*/

	for(i=0;i<(n-1);i++)
	{
		y[i+1]=y[i]+dt*fn(t[i],y[i]);
		t[i+1]=t[i]+dt;
		yr[i+1]=fn2(t[i+1]);			/*Euler method*/
		err[i+1]=fabs(y[i+1]-yr[i+1]);
		erb[i+1]=(1./20.)*(exp(2)-4)*(exp(t[i+1])-1);
		printf("t=");
		printf("%lf\t",t[i+1]);
		printf("error=");
		printf("%lf\t",err[i+1]);
		printf("error bound=");  /*finding error and error bound*/
		printf("%lf\n",erb[i+1]);
		/*fprintf(mptr,"%e\t%e\t%e\n",t[i+1],y[i+1],yr[i+1]);*/
	}
	
	   



   	return(0);
}



