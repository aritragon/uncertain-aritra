#use of adaptive step-size control with the RK4 method 
import numpy as np
import math
import matplotlib.pyplot as plt
h1=0.1
h2=2*h1
t1=1.0
t2=t1
y1=-2 #initial conditions
y2=y1 
delta=0.000001  #abs accuracy
0
T=[]
x1=[]
x1.append(y1)
T.append(t1)
def fn(y,t):
	return((y*y+y)/t)

while(t1<=30.0):
	rec1=y1
	rec2=t1
	#print("t=",x,"\t","y=",y,"\t","v=",v,"\n")
	p1=h1*(fn(y1,t1))			
	p2=h1*(fn(y1+p1/2,t1+h1/2))
	p3=h1*(fn(y1+p2/2,t1+h1/2))
	p4=h1*(fn(y1+p3,t1+h1))
	y1=y1+(1/6)*(p1+2*p2+2*p3+p4)    #increment by h
	rec3=y1
	t1=t1+h1

	p1=h1*(fn(y1,t1))			
	p2=h1*(fn(y1+p1/2,t1+h1/2))
	p3=h1*(fn(y1+p2/2,t1+h1/2))
	p4=h1*(fn(y1+p3,t1+h1))		#increment by h more
	y1=y1+(1/6)*(p1+2*p2+2*p3+p4)
	t1=t1+h1

	
	k1=h2*(fn(y2,t2))			
	k2=h2*(fn(y2+k1/2,t2+h2/2))
	k3=h2*(fn(y2+k2/2,t2+h2/2))
	k4=h2*(fn(y2+k3,t2+h2))		#direct increment by 2h
	y2=y2+(1/6)*(k1+2*k2+2*k3+k4)
	t2=t2+h2
	#print(h1*pow(delta*30/(abs(y2-y1)),1/5))
	if(h1*pow(delta*30/(abs(y2-y1)),1/5)<h1):
		h1=h1*pow(delta*30/(abs(y2-y1)),1/5)
		h2=2*h1
		y1=rec1				#to find optimal h
		t1=rec2
		y2=rec1
		t2=rec2

	else:
		x1.append(rec3)
		T.append(t1-h1)
		h1=h1*pow(delta*30/(abs(y2-y1)),1/5)
		h2=2*h1
		
		



a1 = np.asarray(x1)
time= np.asarray(T)

plt.plot(time,a1,color="r",marker="*",markersize="3")
plt.xlabel('t')    #plotting
plt.ylabel('y(t)') 
plt.show()












