#include <stdio.h>
#include<stdlib.h>
#include<math.h>
#include<gsl/gsl_math.h>
#include<gsl/gsl_vector.h>
#include<gsl/gsl_matrix.h>
#include<gsl/gsl_linalg.h>

int 
main()
{
	float x;
	int s;
	gsl_matrix *A=gsl_matrix_calloc(3,3);
	gsl_vector *b=gsl_vector_calloc(3);
	gsl_vector *z=gsl_vector_calloc(3);
	/*gsl_matrix *LU=gsl_matrix_calloc(3,3);*/
	gsl_permutation *p = gsl_permutation_alloc(3);

	printf("Enter Matrix A:\n");
	for(int i=0;i<3;i++)
	{
	   for(int j=0;j<3;j++)
	   {	
		printf("enter\n");
		scanf("%f", &x);
		gsl_matrix_set(A,i,j,x);
	   }
	}
	printf("Enter vector b:\n");

	for(int j=0;j<3;j++)
	   {	
		printf(" enter\n");
		scanf("%f", &x);
		gsl_vector_set(b,j,x);
	   }
	gsl_linalg_LU_decomp(A, p,&s);
	gsl_linalg_LU_solve (A, p, b, z);
	
	printf("The solution is:\n");

	for(int j=0;j<3;j++)
	   {	
		printf("%lf\n",gsl_vector_get (z, j));
	   }
	return(0);
}
