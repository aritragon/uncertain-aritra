# To find the dominant eigenvalue
import numpy as np
A=np.array([[2.0,-1.0,0.0],[-1.0,2.0,-1.0],[0.0,-1.0,2.0]])
xo=np.array([1,1,1])
flag=0.1
vec=np.matmul(A,xo)
#store=vec
pv=np.matmul(np.transpose(vec),vec)
nv=np.matmul(np.transpose(np.matmul(A,vec)),vec)
#store=vec
plam=nv/pv
while(abs(flag)>0.01): #Setting the tolerance limit
	vec=np.matmul(A,vec)
	pv=np.matmul(np.transpose(vec),vec)
	nv=np.matmul(np.transpose(np.matmul(A,vec)),vec)
	nlam=nv/pv
	flag=plam-nlam #for comparison
	plam=nlam

print("The dominant eigenvalue is: ",nlam)
print("The dominant eigenvector is: ",vec)
