
import numpy as np
import math
import time
np.set_printoptions(precision=3)
np.set_printoptions(suppress=True)
A=np.array([[0.0,1.0,1.0],[0.0,1.0,0.0],[1.0,1.0,0.0],[0.0,1.0,0.0],[1.0,0.0,1.0]]) #Initial matrix (5cross3)

#manually finding out U, S, V matrices
t1=time.time()
AT=np.transpose(A)
B1=np.matmul(AT,A)
B2=np.matmul(A,AT)

ev1,V=np.linalg.eig(B1)
sev1=ev1.argsort()[::-1]
V=V[:,sev1]


ev2,U=np.linalg.eig(B2)
sev2=ev2.argsort()[::-1]
U=U[:,sev2]

S=np.dot(np.dot(np.transpose(U),A),V)
V=np.transpose(V)

print("V\n",V,"\n")
print("U\n",U,"\n")
print("S\n",S,"\n")
print('Time required = ',(time.time()-t1))

A1=np.matmul(np.matmul(U,S),V)
print("A1\n",A1)
t2=time.time()
U1,S1,V1=np.linalg.svd(A) #Using inbuild libraries

print('SVD form using np.linalg.svd: \n')
print("V\n",V1,"\n")
print("U\n",U1,"\n")
print("S\n",S1,"\n")
print('Time required: ',(time.time()-t2))
