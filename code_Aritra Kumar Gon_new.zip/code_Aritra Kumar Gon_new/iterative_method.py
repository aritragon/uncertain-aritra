import numpy as np
from numpy.linalg import inv
A=np.array([[0.2,0.1,1.0,1.0,0.0],[0.1,4.0,-1.0,1.0,-1.0],[1.0,-1.0,60.0,0.0,-2.0],[1.0,1.0,0.0,8.0,4.0],[0.0,-1.0,-2.0,4.0,700.0]])
b=np.array([1.0,2.0,3.0,4.0,5.0])
xsol=np.array([7.859713071,0.422926408,-0.073592239,-0.540643016,0.010626163]) # True solution of linear set of equations AX=B


####1. Jacobi method#####
D=np.diag([0.2,4.0,60.0,8.0,700.0])
U=np.triu(-A,1)
L=np.tril(-A,-1)
x=np.zeros(5) #initial guess
count=0
flag=0
i=0

while ( flag!=5 and count<20 ):
	x=np.matmul(inv(D),np.matmul((L+U),x))+np.matmul(inv(D),b)
	#print(x)
	flag=0;
	for i in range(0,5): #Comparison part
		if abs(x[i]-xsol[i])<0.01:# Setting the tolerance 0.01 on error in iterative soln
			flag=flag+1
	count=count+1


print('The solution from Jocobi Method: ', x)
print('The number of iterations required: ', count)



###2.Gauss siedel###
x=np.zeros(5)
count=0
flag=0
i=0

while ( flag!=5 ):
	
	x=np.matmul(np.matmul(inv(D-L),U),x)+np.matmul(inv(D-L),b)
	#print(x)
	flag=0
	for i in range(0,5):
		if abs(x[i]-xsol[i])<0.01:
			flag=flag+1
	count=count+1

print('The solution from Gauss siedel Method: ', x)
print('The number of iterations required: ', count)
#print(flag)	

###3.Relaxation method ####

x=np.zeros(5)
count=0
flag=0
i=0
w=1.25
while ( flag!=5 ):
	T=np.matmul(inv(D-w*L),(1-w)*D+w*U)
	C=w*(inv(D-w*L))
	x=np.matmul(T,x)+np.matmul(C,b)
	#print(x)
	flag=0
	for i in range(0,5):
		if abs(x[i]-xsol[i])<0.01:
			flag=flag+1
	count=count+1

print('The solution from Relaxation Method: ', x)
print('The number of iterations required: ', count)
#print(flag)	

####4.Conjugate gradient method####
x = np.zeros(5)
g = b - np.dot(A,x)
k = g
xcom4 = abs(xsol)
count = 0

	
while(np.any(xcom4 > 0.01)): # Setting the tolerance 0.01 on error in iterative soln
	b1 =  (np.matmul(np.transpose(g), g))/(np.matmul(np.transpose(k), np.matmul(A,k)))
	x = x + b1*k
	gi = g
	g = g - b1*(np.matmul(A,k))
	l =  ((np.matmul(np.transpose(g),g)))/(np.matmul(np.transpose(gi),gi))
	k = g + l*k
	count = count + 1
	xcom4 = abs(xsol - x) 
print('The solution from Conjugate gradient Method: ', x)
print('The number of iterations required: ', count)






















