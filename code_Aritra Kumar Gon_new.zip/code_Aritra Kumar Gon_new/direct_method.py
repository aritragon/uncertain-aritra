#Direct method to find the solution for the equation AX=B
import numpy as np

A=np.array([[1.0,0.67,0.33],[0.45,1.0,0.55],[0.67,0.33,1.0]])
B=np.array([2.0,2.0,2.0])

X=np.linalg.solve(A,B)
print("The solution to the equation is",X)


