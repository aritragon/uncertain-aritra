#To find the eigenvalue using the QR decomposition
import numpy as np
from numpy.linalg import qr
A=np.array([[5.0,-2.0],[-2.0,8.0]])

U=np.triu(A,1)
L=np.tril(A,-1)
A1=abs(np.diag(np.diag(A)))
count=0

while (np.any(A1>0.001)):
	q, r = np.linalg.qr(A)
	A=np.matmul(r,q)
	A1=abs(A-np.diag(np.diag(A)))	
	count=count+1

E=np.diag(A)
#print(count)
print("The eigenvalues using qr decomposition is\n",E,"\n")
print("The eigenvalues using np.linalg.eigvals is\n",np.linalg.eigvals(A))
